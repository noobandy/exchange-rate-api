package in.anandm.todojsp;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(value = "/todos")
public class TodoServerlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String todosView;

	private Store store;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		todosView = config.getServletContext().getInitParameter("viewBaseDir") + "todos.jsp";
		store = (Store) config.getServletContext().getAttribute("store");
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		if (id == null || id.isEmpty()) {
			req.setAttribute("message", "todoDeleteError");
			doGet(req, resp);
			return;
		}

		long idLong = -1;

		try {
			idLong = Long.parseLong(id);
		} catch (NumberFormatException e) {
			req.setAttribute("message", "todoDeleteError");
			doGet(req, resp);
			return;
		}

		Todo todo = store.findTodoById(idLong);

		if (todo == null) {
			req.setAttribute("message", "todoDeleteError");
		}

		store.deleteTodo(todo);
		req.setAttribute("message", "todoDeleteSuccess");

		resp.sendRedirect(req.getContextPath() + "/todos");
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);
		User currentUser = (User) session.getAttribute("user");

		List<Todo> todos = store.findTodosOfUser(currentUser.getUsername());
		req.setAttribute("todos", todos);

		RequestDispatcher dispatcher = req.getRequestDispatcher(todosView);
		dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String httpMethod = req.getParameter("_http_method_");

		if (httpMethod != null && !httpMethod.isEmpty()) {
			switch (httpMethod.toLowerCase()) {
			case "delete":
				doDelete(req, resp);
				break;
			case "put":
				doPut(req, resp);
				break;
			default:
				resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			}

			return;
		}

		String task = req.getParameter("task");

		if (task == null || task.isEmpty()) {
			req.setAttribute("message", "newTaskError");
			doGet(req, resp);
			return;
		}

		Todo todo = new Todo(task);
		HttpSession session = req.getSession(false);

		todo.setUser((User) session.getAttribute("user"));

		store.saveTodo(todo);
		req.setAttribute("message", "newTaskSuccess");

		resp.sendRedirect(req.getContextPath() + "/todos");
	}

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		String task = req.getParameter("task");
		String completed = req.getParameter("completed");

		if (id == null || id.isEmpty() || task == null || task.isEmpty() || completed == null || completed.isEmpty()) {
			req.setAttribute("message", "todoDeleteError");
			doGet(req, resp);
			return;
		}

		long longId = -1;

		try {
			longId = Long.parseLong(id);

		} catch (NumberFormatException e) {
			req.setAttribute("message", "todoDeleteError");
			doGet(req, resp);
			return;
		}

		boolean boolCompleted = Boolean.parseBoolean(completed);
		
		Todo todo = new Todo(task);
		todo.setId(longId);
		todo.setCompleted(boolCompleted);
		HttpSession session = req.getSession(false);
		
		todo.setUser((User) session.getAttribute("user"));

		store.saveTodo(todo);
		
		req.setAttribute("message", "updateTaskSuccess");

		resp.sendRedirect(req.getContextPath() + "/todos");

	}

}
