package in.anandm.todojsp;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(value="/login")
public class LoginServlet extends HttpServlet {
	
	private String indexView;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		String viewBaseDir = config.getServletContext().getInitParameter("viewBaseDir");
		indexView = viewBaseDir + "index.jsp";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private User validateLogin(String username, String password, Store store) {
		boolean validInput = username != null && !username.isEmpty() && password != null && !password.isEmpty();
		
		if (!validInput) {
			return null;
		}
		
		User user = store.findUser(username);
		
		boolean validCredentials = user != null && user.getPassword().equals(password);
		if(validCredentials) {
			return user;
		}
		
		return null;
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Store store = (Store) request.getServletContext().getAttribute("store");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		User validUser = validateLogin(username, password, store);
		if(validUser != null) {
			HttpSession userSession = request.getSession(true);
			userSession.setAttribute("user", validUser);
			response.sendRedirect(request.getContextPath()+"/todos");
		} else {
			request.setAttribute("loginError", "Invalid Credentials");
			request.setAttribute("username", username);
			request.setAttribute("password", password);
			RequestDispatcher dispatcher = request.getRequestDispatcher(indexView);
			dispatcher.forward(request, response);
		}
	}
	
	

}
