package in.anandm.todojsp;

public interface UserStore {

	void add(User user);
	
	User find(String username);
}
