package in.anandm.todojsp.aspects;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

public class MemoryCache<K extends Serializable, V extends Serializable> implements Cache<K, V> {

	private class KeyExpiry implements Delayed {
		K key;
		long expiryInMilliseconds;
		
		@Override
		public int compareTo(Delayed o) {
			KeyExpiry obj = (KeyExpiry) o;
			
			return Long.compare(expiryInMilliseconds, obj.expiryInMilliseconds);
		}
		
		@Override
		public long getDelay(TimeUnit unit) {
			return unit.convert(System.currentTimeMillis() - expiryInMilliseconds, TimeUnit.MILLISECONDS);
		}
	}
	
	private Map<K, V> map;
	
	private DelayQueue<Delayed> expiryQueue;
	
	
	public MemoryCache() {
		this(100);
	}
	public MemoryCache(int initialCapacity) {
		super();

		map = new ConcurrentHashMap<>(initialCapacity);
		expiryQueue = new DelayQueue<>();
	}

	@Override
	public void set(K key, V value) {
		set(key, value, 0);
	}

	@Override
	public V get(K key) {
		return map.get(key);
	}

	@Override
	public boolean contains(K key) {
		return map.containsKey(key);
	}

	@Override
	public void remove(K key) {
		map.remove(key);

	}

	@Override
	public void set(K key, V value, long expiresInMillis) {
		
	}

}
