package in.anandm.todojsp;

import java.util.Arrays;
import java.util.List;

public class Chain {
	private List<Link> links;

	private int nextLink;

	public Chain(List<Link> links) {
		super();
		this.links = links;
	}

	public void walkChain() {
		if(links.size() == 0) {
			return;
		}
		
		Link l = links.get(nextLink++);
		
		l.link(this);
	}

	public void nextLink() {
		if (nextLink < links.size()) {
			Link l = links.get(nextLink++);
			l.link(this);
		}
	}

	public static void main(String[] args) {
		Chain chain = new Chain(Arrays.asList(new Link[] { (c) -> {
			System.out.println("Before chain 1");
			c.nextLink();
			System.out.println("After chain 1");
		}, (c) -> {
			System.out.println("Before chain 2");
			c.nextLink();
			System.out.println("After chain 2");
		}, (c) -> {
			System.out.println("Before chain 3");
			c.nextLink();
			System.out.println("After chain 3");
		} }));
		
		chain.walkChain();
	}
}
