package in.anandm.framework;

import java.util.Map;

public interface Request {
	
	public  RequestMethod getMethod();
	
	public String getPath();
	
	public Map<String, String> getHeaders();
	
	public Map<String, String> getParameters();
	
}
