package in.anandm.framework;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;

public class App {
	private static class RequestHandler implements Runnable {
		private Socket socket;

		public RequestHandler(Socket socket) {
			super();
			this.socket = socket;
		}

		private String readLine(InputStream is) throws IOException {
			int b = -1;
			StringBuilder sb = new StringBuilder();

			while ((b = is.read()) != -1) {
				if (b == '\r') {
					b = is.read();

					assert b == '\n';
					break;
				}

				sb.append((char) b);
			}

			return sb.length() > 0 ? sb.toString() : null;
		}

		@Override
		public void run() {
			HttpServletRequest 
			System.out.println("in handler");
			try {
				InputStream is = socket.getInputStream();
				BufferedOutputStream bo = new BufferedOutputStream(socket.getOutputStream());
				String line = null;
				while ((line = readLine(is)) != null) {
					System.out.println(line);
					bo.write(line.getBytes());
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				close();

			}

			System.out.println("done");
		}

		private void close() {
			try {
				socket.close();
				System.out.println("socket closed");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) throws IOException {
		ExecutorService executorService = Executors.newCachedThreadPool();
		ServerSocket serverSocket = new ServerSocket(8080);

		while (true) {
			Socket socket = serverSocket.accept();
			System.out.println(socket);
			executorService.submit(new RequestHandler(socket));
		}
	}
}
