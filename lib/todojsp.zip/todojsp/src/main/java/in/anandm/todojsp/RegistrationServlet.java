package in.anandm.todojsp;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value = "/register")
public class RegistrationServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String indexView;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		String viewBaseDir = config.getServletContext().getInitParameter("viewBaseDir");
		indexView = viewBaseDir + "index.jsp";
	}

	private boolean registerUser(HttpServletRequest request, Store store) {
		String email = request.getParameter("email");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String confirmPassword = request.getParameter("confirmPassword");
		String country = request.getParameter("country");
		String sex = request.getParameter("sex");
		String acceptTermsAndConditions = request.getParameter("acceptTermsAndConditions");

		FormErrors errors = new FormErrors();

		if (email == null || email.isEmpty()) {
			errors.addFieldError("email", "email required");
		}

		if (username == null || username.isEmpty()) {
			errors.addFieldError("username", "username required");
		}

		if (!errors.hasFieldErrors("username")) {
			User found = store.findUser(username);
			if (found != null) {
				errors.addFieldError("username", "username already taken");
			}
		}

		if (password == null || password.isEmpty()) {
			errors.addFieldError("password", "password required");
		}

		if (confirmPassword == null || confirmPassword.isEmpty()) {
			errors.addFieldError("confirmPassword", "confirmPassword required");
		}

		if (!errors.hasFieldErrors("password") && !errors.hasFieldErrors("confirmPassword")) {
			if (!confirmPassword.equals(password)) {
				errors.addFieldError("confirmPassword", "confirm password must be same as password");
			}
		}

		if (country == null || country.isEmpty()) {
			errors.addFieldError("country", "country required");
		}

		if (!errors.hasFieldErrors("country")) {
			Masters.Country countryEnum = Masters.Country.valueOf(country);

			if (countryEnum == null) {
				errors.addFieldError("country", "Invalid value");
			}
		}

		if (sex == null || sex.isEmpty()) {
			errors.addFieldError("sex", "sex required");
		}

		if (!errors.hasFieldErrors("sex")) {
			Masters.Sex sexEnum = Masters.Sex.valueOf(sex);

			if (sexEnum == null) {
				errors.addFieldError("sex", "Invalid value");
			}
		}

		if (acceptTermsAndConditions == null || acceptTermsAndConditions.isEmpty()) {
			errors.addFieldError("agreedToTerms", "must agree to terms and conditions");
		}

		if (errors.hasErrors()) {
			request.setAttribute("errors", errors);
			request.setAttribute("email", email);
			request.setAttribute("username", username);
			request.setAttribute("password", password);
			request.setAttribute("confirmPassword", confirmPassword);
			request.setAttribute("country", country);
			request.setAttribute("sex", sex);
			request.setAttribute("acceptTermsAndConditions", acceptTermsAndConditions);
			return false;
		}

		User user = new User(email, username, password, country, sex);

		store.saveUser(user);
		return true;
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Store store = (Store) request.getServletContext().getAttribute("store");
		if (registerUser(request, store)) {
			response.sendRedirect(request.getContextPath() + "/?registrationSuccess=true");
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher(indexView);
			dispatcher.forward(request, response);
		}
	}

}
