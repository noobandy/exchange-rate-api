package in.anandm.framework;

public enum RequestMethod {
	GET, POST;
}
