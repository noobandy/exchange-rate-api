package in.anandm.todojsp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TargetTwoSum {
	
	private static boolean hasSUM(long[] nums, long target) {
		Map<Long, Boolean> numMap = new HashMap<>();
		for(int i = 0; i < nums.length; i++) {
			long searchKey = target - nums[i];
			if(searchKey != nums[i] && numMap.containsKey(searchKey)) {
				return true;
			}
			
			numMap.put(nums[i], true);
		}
		
		return false;
	}
	
	public static void main(String[] args) throws IOException {
		int start = Integer.parseInt(args[0].trim());
		int end = Integer.parseInt(args[1].trim());
		int inputSize = Integer.parseInt(args[2].trim());
		long[] nums = new long[inputSize];
		String inputFile = args[3];
		
		BufferedReader br = null;
		int i = 0;
		try {
			br = new BufferedReader(new FileReader(inputFile));
			String line = null;
			while((line = br.readLine()) != null) {
				long num = Long.parseLong(line.trim());
				nums[i++] = num;
			}
		} finally {
			if(br != null) {
				br.close();
			}
		}
		
		int result = 0;
		for(int t = start; t <= end; t++) {
			if(hasSUM(nums, t)) {
				result++;
			}
		}
		
		System.out.println(result);
	}

}