package in.anandm.todojsp.aspects;

import java.io.Serializable;

public interface Cache<K extends Serializable, V extends Serializable> {

	 void set(K key, V value);
	 
	 void set(K key, V value, long expiresInMillis);
	 
	 V get(K key);
	 
	 boolean contains(K key);
	 
	 void remove(K key);
}
