package in.anandm.todojsp;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryUserStore implements UserStore {

	private Map<String, User> users;
	
	
	public InMemoryUserStore() {
		super();
		users = new ConcurrentHashMap<>();
	}

	@Override
	public void add(User user) {
		users.put(user.getUsername(), user);
	}

	@Override
	public User find(String username) {
		User found = users.get(username);
		return found;
	}

}
