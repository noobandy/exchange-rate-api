package in.anandm.todojsp;

import java.io.InputStream;
import java.util.List;

public interface Store {

	void saveUser(User user);
	
	User findUser(String username);
	
	List<Todo> findTodosOfUser(String username);
	
	void saveTodo(Todo todo);
	
	void deleteTodo(Todo todo);
	
	Todo findTodoById(long id);
	
	void saveUserProfilePic(String username, String name, InputStream in);
	
	InputStream getUserProfilePic(String username);
}
