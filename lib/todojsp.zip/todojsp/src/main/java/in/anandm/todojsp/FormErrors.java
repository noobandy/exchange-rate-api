package in.anandm.todojsp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FormErrors {
	
	private List<String> globalErrors;
	private Map<String, List<String>> fieldErrors;
	
	public FormErrors() {
		super();
		globalErrors = new ArrayList<>();
		fieldErrors = new HashMap<>();
	}
	
	
	public void addFieldError(String field, String error) {
		List<String> errors = fieldErrors.get(field);
		
		if(errors == null) {
			errors = new ArrayList<>();
		}
		
		errors.add(error);
		
		fieldErrors.put(field, errors);
	}
	
	public void addGlobalError(String error) {
		globalErrors.add(error);
	}
	
	public boolean hasErrors() {
		return globalErrors.size() > 0 || fieldErrors.size() > 0;
	}
	
	public boolean hasFieldErrors(String field) {
		return fieldErrors.containsKey(field);
	}
	
	public List<String> getGlobalErrors() {
		return Collections.unmodifiableList(globalErrors);
	}


	public Map<String, List<String>> getFieldErrors() {
		return Collections.unmodifiableMap(fieldErrors);
	}
	
	
	
}
