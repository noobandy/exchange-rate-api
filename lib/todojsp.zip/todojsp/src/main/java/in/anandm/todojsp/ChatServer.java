package in.anandm.todojsp;

import javax.websocket.Endpoint;
import javax.websocket.EndpointConfig;
import javax.websocket.MessageHandler;
import javax.websocket.Session;

public class ChatServer extends Endpoint {

	@Override
	public void onOpen(Session session, EndpointConfig config) {
		session.addMessageHandler(new ChatMessageHandler());
	}
	
	
	private class ChatMessageHandler implements MessageHandler.Whole<String> {

		@Override
		public void onMessage(String message) {
			System.out.println(message);
		}
		
	}

}
