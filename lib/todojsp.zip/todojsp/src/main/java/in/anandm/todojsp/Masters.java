package in.anandm.todojsp;

public class Masters {
	
	public enum Country {
		India("India"),
		Nepal("Nepal"),
		China("China");
		
		private String name;
		
		private Country(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}
		
	}
	
	public enum Sex {
		Male("Male"),
		Female("Female");
		
		private String name;
		
		private Sex(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}
		
	}
}
