package in.anandm.todojsp;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

public class JDBCStore implements Store {

	private DataSource datasource;

	private static final String INSERT_USER = "INSERT INTO users (email, username, password, country, sex) values(?, ?, ?, ?, ?)";
	private static final String FIND_USER_BY_USERNAME = "SELECT id, email, username, password, country, sex, profile_pic_name, last_modified FROM users WHERE username = ?";
	private static final String UPDATE_USER_PROFILE_PIC = "UPDATE users SET profile_pic_name=?, profile_pic_data=? WHERE username=?";
	private static final String FIND_PROFILE_PIC_DATA_BY_USERNAME = "SELECT profile_pic_data FROM users WHERE username = ?";
	private static final String FIND_TODOS_OF_USER = "SELECT * FROM tasks WHERE user_id = ?";
	private static final String INSERT_TODO = "INSERT INTO tasks (content, user_id) values(?, ?)";
	private static final String UPDATE_TODO = "UPDATE tasks SET content=?, completed=? WHERE id=?";
	private static final String DELETE_TODO = "DELETE FROM tasks WHERE id=?";
	private static final String FIND_TODO_BY_ID = "SELECT t.*, u.email, u.username, u.password,u.sex, u.country FROM tasks t JOIN users u ON t.user_id = u.id where t.id=?";

	public JDBCStore(DataSource datasource) {
		super();
		this.datasource = datasource;
	}

	@Override
	public void saveUser(User user) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = datasource.getConnection();

			statement = connection.prepareStatement(INSERT_USER, Statement.RETURN_GENERATED_KEYS);
			statement.setString(1, user.getEmail());
			statement.setString(2, user.getUsername());
			statement.setString(3, user.getPassword());
			statement.setString(4, user.getCountry());
			statement.setString(5, user.getSex());

			int inserted = statement.executeUpdate();
			if (inserted > 0) {
				resultSet = statement.getGeneratedKeys();
				long id = -1;

				while (resultSet.next()) {
					id = resultSet.getLong(1);
					break;
				}
				user.setId(id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(connection, statement, resultSet);
		}
	}

	@Override
	public User findUser(String username) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		User found = null;
		try {
			connection = datasource.getConnection();
			statement = connection.prepareStatement(FIND_USER_BY_USERNAME);
			statement.setString(1, username);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				found = new User(resultSet.getString("email"), resultSet.getString("username"),
						resultSet.getString("password"), resultSet.getString("country"), resultSet.getString("sex"));

				found.setId(resultSet.getLong("id"));
				found.setProfilePicURL(resultSet.getString("profile_pic_name"));
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(connection, statement, resultSet);
		}

		return found;
	}

	@Override
	public List<Todo> findTodosOfUser(String username) {
		List<Todo> todos = new ArrayList<>();

		User found = findUser(username);

		if (found == null) {
			return todos;
		}

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;

		try {
			connection = datasource.getConnection();
			statement = connection.prepareStatement(FIND_TODOS_OF_USER);
			statement.setLong(1, found.getId());
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				Todo todo = new Todo(resultSet.getString("content"));
				todo.setId(resultSet.getLong("id"));
				todo.setCompleted(resultSet.getBoolean("completed"));
				todo.setLastModified(resultSet.getDate("last_modified"));
				todo.setUser(found);

				todos.add(todo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(connection, statement, resultSet);
		}

		return todos;
	}
	

	@Override
	public void saveTodo(Todo todo) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = datasource.getConnection();

			if (todo.getId() != null) {
				statement = connection.prepareStatement(UPDATE_TODO);
				statement.setString(1, todo.getTask());
				statement.setBoolean(2, todo.isCompleted());
				statement.setLong(3, todo.getId());
				
				statement.executeUpdate();

			} else {
				statement = connection.prepareStatement(INSERT_TODO, Statement.RETURN_GENERATED_KEYS);
				statement.setString(1, todo.getTask());
				statement.setLong(2, todo.getUser().getId());
				int inserted = statement.executeUpdate();
				if (inserted > 0) {
					resultSet = statement.getGeneratedKeys();
					long id = -1;

					while (resultSet.next()) {
						id = resultSet.getLong(1);
						break;
					}
					todo.setId(id);
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(connection, statement, resultSet);
		}
	}

	@Override
	public void deleteTodo(Todo todo) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = datasource.getConnection();
			statement = connection.prepareStatement(DELETE_TODO);
			statement.setLong(1, todo.getId());
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(connection, statement, resultSet);
		}
		
	}
	
	@Override
	public Todo findTodoById(long id) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Todo found = null;
		try {
			connection = datasource.getConnection();
			statement = connection.prepareStatement(FIND_TODO_BY_ID);
			statement.setLong(1, id);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				found = new Todo(resultSet.getString("content"));
				found.setCompleted(resultSet.getBoolean("completed"));
				found.setId(resultSet.getLong("id"));
				found.setLastModified(resultSet.getDate("last_modified"));
				
				User user = new User(resultSet.getString("email"), resultSet.getString("username"),
						resultSet.getString("password"), resultSet.getString("country"), resultSet.getString("sex"));
				user.setId(resultSet.getLong("user_id"));
				
				found.setUser(user);
				break;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(connection, statement, resultSet);
		}
		
		return found;
	}
	
	
	private void close(Connection connection, Statement statement, ResultSet resultSet) {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if (statement != null) {
			try {
				statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void saveUserProfilePic(String username, String name, InputStream in) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connection = datasource.getConnection();
			statement = connection.prepareStatement(UPDATE_USER_PROFILE_PIC);
			statement.setString(1, name);
			statement.setBinaryStream(2, in);
			statement.setString(3, username);
			statement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(connection, statement, resultSet);
		}
	}

	@Override
	public InputStream getUserProfilePic(String username) {
		System.out.println("Inside getUserProfileData");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		InputStream in = null;
		try {
			connection = datasource.getConnection();
			statement = connection.prepareStatement(FIND_PROFILE_PIC_DATA_BY_USERNAME);
			statement.setString(1, username);
			resultSet = statement.executeQuery();
			while(resultSet.next()) {
				in = resultSet.getBlob("profile_pic_data").getBinaryStream();
				break;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(connection, statement, resultSet);
		}
		
		return in;
	}

	

	
}
