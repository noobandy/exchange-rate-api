package in.anandm.todojsp;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class AuthenticationFilter
 */
@WebFilter(filterName = "authFilter", urlPatterns = { "/todos", "/userProfile", "/userProfile/profilePic/*" })
public class AuthenticationFilter implements Filter {

	private String userAttributeName;
    /**
     * Default constructor. 
     */
    public AuthenticationFilter() {
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		
		boolean allowed = false;
		
		HttpSession session = req.getSession(false);
		
		if(session != null) {
			User user = (User) session.getAttribute(userAttributeName);
			if(user != null) {
				allowed = true;
			}
		}
		
		if(allowed) {
			// pass the request along the filter chain
			chain.doFilter(request, response);
		} else {
			resp.sendRedirect(req.getContextPath() + "/");
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		userAttributeName = fConfig.getInitParameter("userAttributeName") == null ? "user" : fConfig.getInitParameter("userAttributeName");
	}

}
