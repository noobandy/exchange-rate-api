package in.anandm.todojsp;

public interface Link {
	void link(Chain chain);
}
