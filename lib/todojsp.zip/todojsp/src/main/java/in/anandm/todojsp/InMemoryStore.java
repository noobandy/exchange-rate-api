package in.anandm.todojsp;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InMemoryStore implements Store {

	private Map<String, User> users;
	private Map<String, List<Todo>> todos;
	
	
	public InMemoryStore() {
		super();
		users = new HashMap<>();
		todos = new HashMap<>();
	}

	@Override
	public void saveUser(User user) {
		users.put(user.getUsername(), user);
	}

	@Override
	public User findUser(String username) {
		User found = users.get(username);
		return found;
	}

	@Override
	public List<Todo> findTodosOfUser(String username) {
		if(todos.get(username) == null) {
			return Collections.emptyList();
		} else {
			return Collections.unmodifiableList(todos.get(username));
		}
	}

	@Override
	public void saveTodo(Todo todo) {
		List<Todo> userTodos = todos.computeIfAbsent(todo.getUser().getUsername(), (username) -> {return new ArrayList<>();});
		userTodos.add(todo);
	}

	@Override
	public void deleteTodo(Todo todo) {
		List<Todo> userTodos = todos.computeIfAbsent(todo.getUser().getUsername(), (username) -> {return new ArrayList<>();});
		userTodos.remove(todo);
	}

	@Override
	public Todo findTodoById(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveUserProfilePic(String username, String name, InputStream in) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public InputStream getUserProfilePic(String username) {
		// TODO Auto-generated method stub
		return null;
	}

}
