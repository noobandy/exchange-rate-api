package in.anandm.todojsp;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value="/userProfile/profilePic/*")
public class ProfilePicServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Store store;
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		store = (Store) config.getServletContext().getAttribute("store");
	}


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = usernamePartFromURL(req);
		resp.setContentType("image/jpeg");
		InputStream in = store.getUserProfilePic(username);
		OutputStream out = resp.getOutputStream();
		byte[] buff = new byte[1024];
		int len = -1;
		while((len = in.read(buff)) > 0) {
			out.write(buff, 0, len);
		}
		in.close();
		out.close();
	}
	
	
	private String usernamePartFromURL(HttpServletRequest req) {
		String uri = req.getRequestURI();
		int lastSlash = uri.lastIndexOf('/');
		int lastDot = uri.lastIndexOf('.');
		return uri.substring(lastSlash + 1, lastDot);
	}

	
}
