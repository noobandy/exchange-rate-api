package in.anandm.todojsp;

import javax.annotation.Resource;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.sql.DataSource;

/**
 * Application Lifecycle Listener implementation class ServletContextInitializer
 *
 */
@WebListener
public class ServletContextInitializer implements ServletContextListener {

	@Resource(name="jdbc/todos")
	private DataSource dataSource;
	
    /**
     * Default constructor. 
     */
    public ServletContextInitializer() {
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
    	sce.getServletContext().setAttribute("store", null);
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
    	Store store = new JDBCStore(dataSource);
    	
    	sce.getServletContext().setAttribute("store", store);
    }
	
}
