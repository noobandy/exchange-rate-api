package in.anandm.framework;

import java.util.Enumeration;
import java.util.Map;

public class MyRequest implements Request {
	
	private String path;
	
	private RequestMethod method;
	
	private Map<String, String> headers
	@Override
	public RequestMethod getMethod() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPath() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, String> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, String> getParameters() {
		// TODO Auto-generated method stub
		return null;
	}

}
