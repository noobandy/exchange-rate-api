package in.anandm.todojsp;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet(value="/userProfile")
@MultipartConfig(fileSizeThreshold=524288, maxFileSize=524288, maxRequestSize=527360 )
public class UserProfileServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Store store;
	private String userProfileView;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		store = (Store) config.getServletContext().getAttribute("store");
		userProfileView = config.getServletContext().getInitParameter("viewBaseDir") + "userProfile.jsp";
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);
		User user = (User) session.getAttribute("user");
		req.setAttribute("user", store.findUser(user.getUsername()));
		
		RequestDispatcher dispatcher = req.getRequestDispatcher(userProfileView);
		
		dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Part part = req.getPart("profilePic");
		long fileSize = part.getSize();
		String name = part.getName();
		String fileName = part.getSubmittedFileName();
		System.out.format("file %s with size %d received as %s\n", fileName, fileSize, name);
		HttpSession session = req.getSession(false);
		User user = (User) session.getAttribute("user");
		String profilePicName = new StringBuilder(user.getUsername()).append(fileExtension(fileName)).toString();
		store.saveUserProfilePic(user.getUsername(), profilePicName, part.getInputStream());
		resp.sendRedirect(resp.encodeURL("userProfile"));
	}
	
	
	private String fileExtension(String fileName) {
		int lastDot = fileName.lastIndexOf('.');
		return fileName.substring(lastDot, fileName.length());
	}
}
