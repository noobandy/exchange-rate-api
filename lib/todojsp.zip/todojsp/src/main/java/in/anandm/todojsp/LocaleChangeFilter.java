package in.anandm.todojsp;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class LocaleChangeFilter
 */
@WebFilter(urlPatterns = { "/*" }, initParams = { @WebInitParam(name = "localeParamName", value = "lang"),
		@WebInitParam(name = "defaultLocale", value = "en_US") })
public class LocaleChangeFilter implements Filter {

	private static final Locale ENG_US = new Locale("en", "US");
	private static final Locale HI_IN = new Locale("hi", "IN");
	private Locale defaultLocale;

	/**
	 * Default constructor.
	 */
	public LocaleChangeFilter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	private Locale toLocale(String lang) {
		switch (lang) {
		case "en_US":
			return ENG_US;
		case "hi_IN":
			return HI_IN;
		default:
			return defaultLocale;
		}
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		Locale locale = defaultLocale;

		Cookie[] cookies = req.getCookies();
		if(cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("lang")) {
					locale = toLocale(cookie.getValue());
					break;
				}
			}
		}
		

		String lang = req.getParameter("lang");

		if (lang != null && !lang.isEmpty()) {
			locale = toLocale(lang);

			Cookie langCookie = new Cookie("lang", lang);
			langCookie.setMaxAge(30 * 24 * 60 * 60); // 30 days

			resp.addCookie(langCookie);
		}

		resp.setLocale(locale);
		// pass the request along the filter chain
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		String defLocale = fConfig.getInitParameter("defaultLocale");
		defLocale = defLocale == null ? "" : defLocale;

		defaultLocale = toLocale(defLocale);
	}

}
