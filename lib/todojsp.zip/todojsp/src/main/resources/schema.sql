-- Create database
create database todos char set utf8 collate utf8_unicode_ci;
-- select databse
use todos;
-- create users table
create table users ( 
	id bigint(20) not null auto_increment primary key,
	email varchar(255) not null,
	username varchar(255) not null,
	password varchar(255) not null,
	country varchar(255) not null,
	sex enum('Male', 'Female') not null,
	last_modified timestamp not null default current_timestamp
);

-- create tasks table
create table tasks (
	id bigint(20) not null auto_increment primary key,
	content text not null,
	completed boolean not null default false,
	last_modified timestamp not null default current_timestamp,
	user_id bigint(20) not null,
	foreign key fk_tasks_user (user_id) references users(id)
);