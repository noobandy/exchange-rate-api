package in.anandm.springmvcdemo.model;

import java.util.List;

public interface TodoRepository {
	
	List<Todo> findAll();
	
	Todo findById(long id);
	
	void save(Todo todo);
	
	void delete(Todo todo);
}
