package in.anandm.springmvcdemo.model;

public class Country {

	private Long id;
	private String name;

	private Country() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Country(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
