package in.anandm.springmvcdemo.model;

public enum Gender {
	MALE, FEMALE, TRANSGENDER;
}
