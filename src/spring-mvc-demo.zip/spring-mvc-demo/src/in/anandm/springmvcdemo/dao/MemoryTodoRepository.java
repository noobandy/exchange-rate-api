package in.anandm.springmvcdemo.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import in.anandm.springmvcdemo.model.Todo;
import in.anandm.springmvcdemo.model.TodoRepository;

public class MemoryTodoRepository implements TodoRepository {

	private Map<Long, Todo> todos = new ConcurrentHashMap<>();
	private AtomicLong sequence = new AtomicLong(0);

	public MemoryTodoRepository() {
		super();
	}

	@Override
	public List<Todo> findAll() {
		List<Todo> view = new LinkedList<>();

		todos.forEach((Long key, Todo value) -> {
			view.add(value);
		});

		return view;
	}

	@Override
	public Todo findById(long id) {
		return todos.get(id);
	}

	@Override
	public void save(Todo todo) {
		if (todo.getId() == null) {
			todo.setId(sequence.incrementAndGet());
		}

		todos.put(todo.getId(), todo);

	}

	@Override
	public void delete(Todo todo) {

		todos.remove(todo.getId());
	}

}
