package in.anandm.springmvcdemo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages={"in.anandm.springmvcdemo.api"})
public class APIConfig {

	
	@Bean
	public ViewResolver viewResolver() {
		ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
		return resolver;
	}
	
	@Bean
	public GsonHttpMessageConverter jsonbHttpMessageConverter() {
		return new GsonHttpMessageConverter();
	}
	
}
