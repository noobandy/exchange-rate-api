package in.anandm.springmvcdemo;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import in.anandm.springmvcdemo.dao.MemoryTodoRepository;
import in.anandm.springmvcdemo.model.TodoRepository;

@Configuration
public class AppConfig {

	
	@Bean
	public TodoRepository todoRepository() {
		return new MemoryTodoRepository();
	}
	
	@Bean
	public MessageSource messageSource() {
		ReloadableResourceBundleMessageSource source = new ReloadableResourceBundleMessageSource();
		source.setBasename("classpath:messages");
		source.setUseCodeAsDefaultMessage(true);
		return source;
	}
}
