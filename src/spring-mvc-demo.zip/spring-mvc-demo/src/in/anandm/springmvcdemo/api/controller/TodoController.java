package in.anandm.springmvcdemo.api.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import in.anandm.springmvcdemo.model.Todo;
import in.anandm.springmvcdemo.model.TodoRepository;

@RestController
public class TodoController {

	@Autowired
	private TodoRepository todoRepository;

	@GetMapping("/todos")
	public ResponseEntity<List<Todo>> getTodos() {
		List<Todo> todos = todoRepository.findAll();

		return ResponseEntity.ok(todos);
	}

	@PostMapping("/todos")
	public ResponseEntity<Todo> addTodo(Todo todo) throws URISyntaxException {
		todoRepository.save(todo);
		return ResponseEntity.created(new URI("")).build();
	}

	@GetMapping("/todos/{id}")
	public ResponseEntity<Todo> getOneTodo(@PathVariable long id) {
		Todo found = todoRepository.findById(id);
		if (found == null) {
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(found);
	}

	@PutMapping("/todos/{id}")
	public ResponseEntity<Todo> updateTodo(@PathVariable long id, Todo todo) {
		Todo found = todoRepository.findById(id);
		if (found == null) {
			return ResponseEntity.notFound().build();
		}

		found.setTask(todo.getTask());
		found.setCompleted(todo.isCompleted());

		todoRepository.save(todo);

		return ResponseEntity.ok().build();
	}

	@DeleteMapping("/todos/{id}")
	public ResponseEntity<Todo> deleteTodo(@PathVariable long id) {
		Todo found = todoRepository.findById(id);
		if (found == null) {
			return ResponseEntity.notFound().build();
		}

		todoRepository.delete(found);

		return ResponseEntity.ok().build();
	}

}
