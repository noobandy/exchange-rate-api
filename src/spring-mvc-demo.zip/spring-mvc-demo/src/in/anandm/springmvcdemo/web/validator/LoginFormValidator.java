package in.anandm.springmvcdemo.web.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import in.anandm.springmvcdemo.web.dto.LoginForm;

@Component(value="loginFormValidator")
public class LoginFormValidator implements Validator {

	
	private LoginFormValidator() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean supports(Class<?> class1) {
		
		return class1.equals(LoginForm.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "LoginForm.username.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "LoginForm.password.required");
	}

}
