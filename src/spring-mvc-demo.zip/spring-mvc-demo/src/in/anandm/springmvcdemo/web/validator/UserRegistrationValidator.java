package in.anandm.springmvcdemo.web.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import in.anandm.springmvcdemo.model.User;

@Component(value="registrationFromValidator")
public class UserRegistrationValidator implements Validator {

	
	private UserRegistrationValidator() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean supports(Class<?> class1) {

		return class1.equals(User.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmpty(errors, "email", "RegistrationForm.email.required");
		ValidationUtils.rejectIfEmpty(errors, "gender", "RegistrationForm.gender.required");
		ValidationUtils.rejectIfEmpty(errors, "dob", "RegistrationForm.dob.required");
		ValidationUtils.rejectIfEmpty(errors, "country", "RegistrationForm.country.required");
		ValidationUtils.rejectIfEmpty(errors, "username", "RegistrationForm.username.required");
		ValidationUtils.rejectIfEmpty(errors, "password", "RegistrationForm.password.required");
		ValidationUtils.rejectIfEmpty(errors, "confirmPassword", "RegistrationForm.confirmPassword.required");
	}

}
