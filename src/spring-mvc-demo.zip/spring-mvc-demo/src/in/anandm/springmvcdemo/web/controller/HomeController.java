package in.anandm.springmvcdemo.web.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

	
	@RequestMapping(value="/", method=RequestMethod.GET, produces={"text/html"})
	public String getHomePage() {
		return "home";
	}
	
	@RequestMapping(value="/", method=RequestMethod.GET, produces={"application/json"})
	public @ResponseBody ResponseEntity<Map<String, String>> getAPIDetails() {
		Map<String, String> res = new HashMap<>();
		res.put("version", "0.0.1");

		return ResponseEntity.ok(res);
	}
	
	@RequestMapping(value="/greet", method=RequestMethod.GET)
	public String greet(@RequestParam(name="who") String who, ModelMap model) {
		model.addAttribute("message", "Welcome "+ who);
		return "home";
	}
	
	@RequestMapping(value="/todos", method=RequestMethod.GET)
	public String getTodoApp() {
		
		return "todos";
	}
}
