package in.anandm.springmvcdemo.web.controller;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import in.anandm.springmvcdemo.model.Country;
import in.anandm.springmvcdemo.model.Gender;
import in.anandm.springmvcdemo.model.User;
import in.anandm.springmvcdemo.web.dto.LoginForm;

@Controller
public class LoginController {

	@Autowired
	@Qualifier(value = "loginFormValidator")
	private Validator loginFormValidator;

	@Autowired
	@Qualifier(value = "registrationFromValidator")
	private Validator registrationFormValidator;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.addValidators(loginFormValidator, registrationFormValidator);
	}

	private static List<Country> countries = new CopyOnWriteArrayList<>();

	static {
		countries.add(new Country(1L, "India"));
		countries.add(new Country(2L, "Nepal"));
		countries.add(new Country(3L, "Bhutan"));

	}

	@GetMapping("/register")
	public String getRegistrationPage(@ModelAttribute("user") User user, ModelMap modelMap) {

		modelMap.addAttribute("user", user);
		populateModelData(modelMap);
		return "login/register";
	}

	@PostMapping("/register")
	public String handleRegistrationPost(@ModelAttribute("user") @Validated User user, BindingResult errors,
			ModelMap modelMap, RedirectAttributes redirectAttributes) {

		if (errors.hasErrors()) {
			modelMap.addAttribute("user", user);
			populateModelData(modelMap);

			return "login/register";
		}

		redirectAttributes.addFlashAttribute("message", "Registration Success");
		return "redirect:login";
	}

	@GetMapping("/login")
	public String getLoginPage(@ModelAttribute(name = "loginModel") LoginForm loginForm, ModelMap modelMap) {
		modelMap.addAttribute("loginForm", loginForm);
		return "login/login";
	}

	@PostMapping("/login")
	public String handleLoginPost(@Validated @ModelAttribute(name = "loginForm") LoginForm loginForm,
			BindingResult errors, ModelMap model, RedirectAttributes redirectAttributes) {
		// loginFormValidator.validate(loginForm, errors);

		if (errors.hasErrors()) {
			model.addAttribute("message", "wrong credentials");
			model.addAttribute("loginForm", loginForm);
			return "login/login";
		}

		redirectAttributes.addAttribute("message", "Login Success");
		return "redirect:todos";
	}

	private void populateModelData(ModelMap modelMap) {
		modelMap.addAttribute("genders", Gender.values());
		modelMap.addAttribute("countrues", Collections.unmodifiableCollection(countries));
	}
}
