var ToDoApp = (function() {
	var config = {}
	
	function createTodoBox() {
		var todoInputBox = document.createElement('input')
		todoInputBox.setAttribute('type', 'text')
		todoInputBox.setAttribute('class', 'todo-box')
		return todoInputBox
	}
	
	function createTodoList(todos) {
		var todoList = document.createElement('ul')
		todoList.setAttribute('class', 'todo-list')
		
		for(var i = 0; i < todos.length; i++) {
			todoList.append(createTodoItem(todos[i]))
		}
		
		return todoList
	}
	
	function createTodoItem(todo) {
		var todoListItem = document.createElement('li')
		todoListItem.setAttribute('class', 'todo-item')
		var todoDiv = document.createElement('div')
		
		var textSpan = document.createElement('span')
		textSpan.append(document.createTextNode(todo.task))
		
		todoDiv.append(textSpan)
		
		var todoCheckBox = document.createElement('input')
		todoCheckBox.setAttribute('type', 'checkbox')
		
		if(todo.completed) {
			todoCheckBox.setAttribute('checked', true)
		}
		
		todoDiv.append(todoCheckBox)
		
		todoListItem.append(todoDiv)
		
		return todoListItem
	}
	
	function createApp(root, todos) {
		var todoAppDiv = document.createElement('div')
		todoAppDiv.setAttribute('class', 'todo-app')
		todoAppDiv.append(createTodoBox())
		todoAppDiv.append(createTodoList(todos))
		root.append(todoAppDiv)
	}
	
	return {
		init(options) {
			config = Object.assign(config, options)
			axios.get(`${config.APIBase}/todos`).then(function(res) {
				console.log(res)
				let todos = res.data
				for(var i = 0; i < 10; i++) {
					todos.push({
						id: i + 1,
						task: `Task ${i + 1}`,
						completed: (i + 1) % 2 == 0
					})
					
				}
				createApp(config.root, todos)
			}).catch(function(err) {
				console.log(err)
			})
		}
	}
})();